# Fish Seg > 2024-02-07 2:09pm
https://universe.roboflow.com/elma7e/fish-seg-yaibp

Provided by a Roboflow user
License: MIT

